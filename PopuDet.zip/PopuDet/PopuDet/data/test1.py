import matplotlib.pyplot as plt
import seaborn as sns
import pandas as pd
import numpy as np

# 创建数据
data = {
    '自然辩证法理解程度': [1, 2, 3, 4, 5, 6, 7, 8, 9, 10],
    '情绪管理能力': [50, 55, 58, 60, 65, 70, 72, 75, 78, 80]
}

# 转换为DataFrame
df = pd.DataFrame(data)

# 输出数据，检查是否正确加载
print(df.head())

# 设置绘图风格
sns.set(style="whitegrid")

# 创建散点图
plt.figure(figsize=(10, 6))
sns.scatterplot(x='自然辩证法理解程度', y='情绪管理能力', data=df, s=100, color='b')

# 添加回归线
sns.regplot(x='自然辩证法理解程度', y='情绪管理能力', data=df, scatter=False, color='r')

# 计算相关系数
correlation = np.corrcoef(df['自然辩证法理解程度'], df['情绪管理能力'])[0, 1]
print(f"相关系数: {correlation:.2f}")

# 设置标题和标签，并添加相关系数
#plt.title(f'自然辩证法理解程度   与情绪管理能力的相关性\n相关系数: {correlation:.2f}', fontsize=16)
plt.xlabel("自然辩证法理解程度", fontsize=14)
plt.ylabel("情绪管理能力", fontsize=14)

# 调整布局以避免标签被剪切
plt.tight_layout()

# 显示图表
plt.show()
