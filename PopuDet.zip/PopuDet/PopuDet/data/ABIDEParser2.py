# mw
import os
import csv
import numpy as np
import scipy.io as sio
import torch.nn.functional as F
from sklearn.linear_model import RidgeClassifier
from sklearn.feature_selection import RFE
from nilearn import connectome
from scipy.spatial import distance
#from test1 import get_name
# Reading and computing the input data
import numpy as np       #mw
import scipy.signal as signal
# Selected pipeline
pipeline = 'cpac'

# Input data variables
root_folder = r'D:/xuting/study experiment/my experiment/DRD-GCN-main/DRD-GCN-main/data'
data_folder = os.path.join(root_folder, 'ABIDE_pcp/cpac/filt_noglobal/')
#phenotype = os.path.join(root_folder, r'/data/Phenotypic_V1_0b_preprocessed1.csv')
phenotype =os.path.join(root_folder,r'ABIDE_pcp/Phenotypic_V1_0b_preprocessed1.csv')
data_folder2 = r'C:/study experiment/MAMF-GCN-main/data/ABIDE_pcp/cpac/filt_noglobal/'

def fetch_filenames(subject_IDs, file_type):
    """
    subject_list : list of short subject IDs in string format
    file_type    : must be one of the available file types

returns:

    filenames    : list of filetypes (same length as subject_list)
    """

    import glob

    # Specify file mappings for the possible file types
    filemapping = {'func_preproc': '_func_preproc.nii.gz',
                   'rois_aal': '_rois_aal.1D'}

    # The list to be filled
    filenames = []

    # Fill list with requested file paths
    for i in range(len(subject_IDs)):
        os.chdir(data_folder)  #data_folder = os.path.join(root_folder, 'ABIDE_pcp/cpac/filt_noglobal/')
        # os.path.join(data_folder, subject_IDs[i]))   os.chdir() 方法用于改变当前工作目录到指定的路径
        try:
            filenames.append(glob.glob('*' + subject_IDs[i] + filemapping[file_type])[0])
        except IndexError:
            # Return N/A if subject ID is not found
            filenames.append('N/A')

    return filenames


# Get timeseries arrays for list of subjects   返回的tiemseries   包括了每个受试者在指定脑图谱下的时间序列数据
def get_timeseries(subject_list, atlas_name):
    """
        subject_list : list of short subject IDs in string format
        atlas_name   : the atlas based on which the timeseries are generated e.g. aal, cc200

    returns:
        time_series  : list of timeseries arrays, each of shape (timepoints x regions)
    """

    timeseries = []
    for i in range(len(subject_list)):
        subject_folder = os.path.join(data_folder, subject_list[i])
        ro_file = [f for f in os.listdir(subject_folder) if f.endswith('_rois_' + atlas_name + '.1D')]
        fl = os.path.join(subject_folder, ro_file[0])
        print("Reading timeseries file %s" %fl)
        timeseries.append(np.loadtxt(fl, skiprows=0))

    return timeseries


# Compute connectivity matrices#计算.mat文件
def subject_connectivity(timeseries, subject, atlas_name, kind, save=True, save_path=data_folder):
    """
        timeseries   : timeseries table for subject (timepoints x regions)
        subject      : the subject ID
        atlas_name   : name of the parcellation atlas used
        kind         : the kind of connectivity to be used, e.g. lasso, partial correlation, correlation
        save         : save the connectivity matrix to a file
        save_path    : specify path to save the matrix if different from subject folder

    returns:
        connectivity : connectivity matrix (regions x regions)
    """

    print("Estimating %s matrix for subject %s" % (kind, subject))

    if kind in ['tangent', 'partial correlation', 'correlation']:
        conn_measure = connectome.ConnectivityMeasure(kind=kind)
        connectivity = conn_measure.fit_transform([timeseries])[0]

    if save:
        subject_file = os.path.join(save_path, subject,
                                    subject + '_' + atlas_name + '_' + kind.replace(' ', '_') + '.mat')
        sio.savemat(subject_file, {'connectivity': connectivity})

    return connectivity


# Get the list of subject IDs
def get_ids(num_subjects=None):  #871
    """

    return:
        subject_IDs    : list of all subject IDs
    """

    subject_IDs =np.genfromtxt(os.path.join(data_folder, 'subject_IDs.txt'), dtype=str)
    #print("test1:" , subject_IDs)

    if num_subjects is not None:
        subject_IDs = subject_IDs[:num_subjects]
    return subject_IDs


# Get phenotype values for a list of subjects
def get_subject_score(subject_list, score):   #表型数据中不是没有得分嘛？怎么有得分勒？
    tempfile = open(phenotype)
    scores_dict = {}
    with open(phenotype) as csv_file:
        reader = csv.DictReader(csv_file)
        for row in reader:
            if row['SUB_ID'] in subject_list:
                scores_dict[row['SUB_ID']] = row[score]
    # print(subject_list)
    #'SUB_ID'键对应的值是分数  将值赋值在列表里进行返回
    return scores_dict


# Dimensionality reduction step for the feature vector using a ridge classifier
def feature_selection(features, labels, train_ind, fnum):  #在特征选择这块修改一下特征选择的方法，它是用的RFE
    """
        matrix       : feature matrix (num_subjects x num_features)
        labels       : ground truth labels (num_subjects x 1)
        train_ind    : indices of the training samples
        fnum         : size of the feature vector after feature selection     最终保留的特征的数量

    return:
        x_data      : feature matrix of lower dimension (num_subjects x fnum)
    """

    estimator = RidgeClassifier()
    RFE(estimator, n_features_to_select=5, step=1)
    selector = RFE(estimator=estimator, n_features_to_select=fnum, step=100, verbose=0)    #步长就是每一步要移除的特征的数量

    featureX = features[train_ind, :]    #训练集的索引
    featureY = labels[train_ind]
    print(type(featureY))  #torch
    print(type(featureX))
    #selector = selector.fit(featureX.cpu().detach().numpy(), featureY.ravel())   #将二维数组展开为一维数组  sx修改过的代码
    selector = selector.fit(featureX, featureY.ravel())  #原代码
    #x_data = selector.transform(features.cpu().detach().numpy())    #使用训练好的特征选择器来对原始的特征矩阵进行特征选择  sx修改过的代码
    x_data = selector.transform(features)  #原代码
    return x_data

#def my_feature_selection(featrues,lables,train_ind,fnum):
    

#get_PLV    计算两个受试者之间的PLV值 ，
def calculate_PLV_between_subjects(subject1_data, subject2_data):
    num_rois = subject1_data.shape[1]
    plv_values = []
    # 设置一个阈值，将相位差大的脑区算在总数里
    threshold_plv = 0.6

    for i in range(num_rois):
        roi1 = subject1_data[:, i]
        roi2 = subject2_data[:, i]

        analytic_signal_g1 = signal.hilbert(roi1)
        analytic_signal_g2 = signal.hilbert(roi2)

        # 检查分母是否为零
        if np.any(analytic_signal_g2 == 0):
            #plv_values.append(0)
            continue

        #不同被试之间的相位差，大于某一个threshold_plv阈值就纳入考虑计算中
        phase_diff = np.angle(analytic_signal_g1 / analytic_signal_g2)
        complex_phase_diff = np.exp(1j * phase_diff)
        plv = np.abs(np.mean(complex_phase_diff))


        if plv>threshold_plv:
            plv_values.append(plv)

    return np.mean(plv_values)

#计算N个受试者之间的PLV值，并返回一个PLV矩阵，##没有用到直接写在一个脚本中了
def calculate_PLV_matrix(data):
    num_subjects = len(data)
    plv_matrix = np.zeros((num_subjects, num_subjects))

    for i in range(num_subjects):
        for j in range(i + 1, num_subjects):
            plv_value = calculate_PLV_between_subjects(data[i], data[j])
            plv_matrix[i, j] = plv_value
            plv_matrix[j, i] = plv_value

    return plv_matrix

# Make sure each site is represented in the training set when selecting a subset of the training set
def site_percentage(train_ind, perc, subject_list):
    """
        train_ind    : indices of the training samples
        perc         : percentage of training set used
        subject_list : list of subject IDs

    return:
        labeled_indices      : indices of the subset of training samples   #最终选择的训练样本的子集
    """

    train_list = subject_list[train_ind]
    sites = get_subject_score(train_list, score='SITE_ID')
    unique = np.unique(list(sites.values())).tolist()  #包含不同地点的列表
    site = np.array([unique.index(sites[train_list[x]]) for x in range(len(train_list))])

    labeled_indices = []

    for i in np.unique(site):
        id_in_site = np.argwhere(site == i).flatten()

        num_nodes = len(id_in_site)
        labeled_num = int(round(perc * num_nodes))
        labeled_indices.extend(train_ind[id_in_site[:labeled_num]])

    return labeled_indices


# Load precomputed fMRI connectivity networks 实现的是获取给定连接性类型（kind）和脑区分割图谱（atlas_name）下，
# 每个受试者对应的连接性网络矩阵，并将这些矩阵展平成一维向量，最后将所有主体的连接性网络向量堆叠成一个特征矩阵。
def get_networks(subject_list, kind, atlas_name="aal", variable='connectivity'):
    """
        subject_list : list of subject IDs
        kind         : the kind of connectivity to be used, e.g. lasso, partial correlation, correlation
        atlas_name   : name of the parcellation atlas used
        variable     : variable name in the .mat file that has been used to save the precomputed networks


    return:
        matrix      : feature matrix of connectivity networks (num_subjects x network_size)
    """
    EPSILON = 1e-10  # 定义一个很小的非零值
    all_networks = []
    for subject in subject_list:
        # fl = os.path.join(data_folder+"ABIDE_pcp/cpac/filt_noglobal/", subject,
        #                   subject + "_" + atlas_name + "_" + kind + ".mat")
        fl = os.path.join(data_folder ,subject+"/",
                   subject + "_" + atlas_name + "_" + kind + ".mat")
        matrix = sio.loadmat(fl)[variable]
        # 将零值替换为EPSILON                                             ###增加EPSILON，避免除零错误
        # matrix_no_zeros = np.where(matrix == 0, EPSILON, matrix)

        # 继续进行其他处理
        # 在计算 arctanh 之前检查输入值并处理无效值
        # matrix_no_zeros = np.maximum(matrix_no_zeros, 1e-6)  # 避免零值
        # matrix_no_zeros = np.minimum(matrix_no_zeros, 1 - 1e-6)  # 避免超出定义域范围
        # norm_mat = np.arctanh(matrix_no_zeros)

        ##norm_mat = np.arctanh(matrix_no_zeros)                          ####
        all_networks.append(matrix)                                   ###matrix->norm_mat
    # all_networks=np.array(all_networks)

    idx = np.triu_indices_from(all_networks[0], 1)

    norm_networks = [np.arctanh(mat) for mat in all_networks]
    vec_networks = [mat[idx] for mat in norm_networks]
    matrix = np.vstack(vec_networks)
#最终将受试者的特征堆叠成了一个一维向量
    return matrix

def get_networks2(subject_list, kind, atlas_name="cc200", variable='connectivity'):
    """
        subject_list : list of subject IDs
        kind         : the kind of connectivity to be used, e.g. lasso, partial correlation, correlation
        atlas_name   : name of the parcellation atlas used
        variable     : variable name in the .mat file that has been used to save the precomputed networks


    return:
        matrix      : feature matrix of connectivity networks (num_subjects x network_size)
    """

    all_networks = []
    for subject in subject_list:
        fl = os.path.join(data_folder, subject+'/',
                          subject + "_" + atlas_name + "_" + kind + ".mat")
        matrix = sio.loadmat(fl)[variable]
        all_networks.append(matrix)
    # all_networks=np.array(all_networks)
        # 在计算 arctanh 之前检查输入值并处理无效值

        matrix_no_zeros = np.maximum(matrix, 1e-6)  # 避免零值
        matrix_no_zeros = np.minimum(matrix_no_zeros, 1 - 1e-6)  # 避免超出定义域范围
        norm_mat = np.arctanh(matrix_no_zeros)

    idx = np.triu_indices_from(all_networks[0], 1)
    norm_networks = [np.arctanh(mat) for mat in all_networks]
    vec_networks = [mat[idx] for mat in norm_networks]
    matrix = np.vstack(vec_networks)

    return matrix

# # Construct the adjacency matrix of the population from phenotypic scores
# def create_affinity_graph_from_scores(scores, subject_list):
#     """
#         scores       : list of phenotypic information to be used to construct the affinity graph
#         subject_list : list of subject IDs
#
#     return:
#         graph        : adjacency matrix of the population graph (num_subjects x num_subjects)
#     """
#
#     num_nodes = len(subject_list)
#     graph = np.zeros((num_nodes, num_nodes))
#
#     for l in scores:
#         label_dict = get_subject_score(subject_list, l)
#
#         # quantitative phenotypic scores
#         if l in ['AGE_AT_SCAN']:
#             for k in range(num_nodes):
#                 for j in range(k + 1, num_nodes):
#                     try:
#                         val = abs(float(label_dict[subject_list[k]]) - float(label_dict[subject_list[j]]))
#                         if val < 2:
#                             graph[k, j] += 1
#                             graph[j, k] += 1
#                     except ValueError:  # missing label
#                         pass
#
#         else:
#             for k in range(num_nodes):
#                 for j in range(k + 1, num_nodes):
#                     if label_dict[subject_list[k]] == label_dict[subject_list[j]]:
#                         graph[k, j] += 1
#                         graph[j, k] += 1
#
#     return graph
def create_affinity_graph_from_scores(scores, pd_dict):  #基于量表中的某一项信息特征计算样本之间的量表数据的相似性，返回的是一个矩阵，矩阵中的值代表样本之间的相似性
    num_nodes = len(pd_dict[scores[0]])   #
    graph = np.zeros((num_nodes, num_nodes)) #

    for l in scores:
        label_dict = pd_dict[l]

        # if l in ['Age','Education (years)']:
        if l in ['AGE_AT_SCAN']:
            for k in range(num_nodes):
                for j in range(k + 1, num_nodes):
                    try:
                        val = abs(float(label_dict[k]) - float(label_dict[j]))   #计算两个数据值之间的绝对差
                        if val < 2:                                              #差小于2特征值之间相似，这种情况下增加两者之间的亲和度
                            graph[k, j] += 1
                            graph[j, k] += 1
                    except ValueError:  # missing label
                        pass
        if l in ['FIQ']:
            for k in range(num_nodes):
                for j in range(k + 1, num_nodes):
                    try:
                        val = abs(float(label_dict[k]) - float(label_dict[j]))
                        if val < 2:
                            graph[k, j] += 1
                            graph[j, k] += 1
                    except ValueError:  # missing label
                        pass
        else:
            for k in range(num_nodes):
                for j in range(k + 1, num_nodes):
                    if label_dict[k] == label_dict[j]:
                        graph[k, j] += 1
                        graph[j, k] += 1

    return graph

def get_static_affinity_adj(features, pd_dict):
    pd_affinity = create_affinity_graph_from_scores(['SITE_ID','DSM_IV_TR'], pd_dict)   #计算亲和图
    #'AGE_AT_SCAN'  'AGE_AT_SCAN','SEX', 'DSM_IV_TR'
    # pd_affinity = (pd_affinity - pd_affinity.mean(axis=0)) / pd_affinity.std(axis=0)
    # print(pd_affinity)
     #pd_affinity = create_affinity_graph_from_scores(['Sex'], pd_dict)
    distv = distance.pdist(features, metric='correlation')
    dist = distance.squareform(distv)
    sigma = np.mean(dist)
    feature_sim = np.exp(- dist ** 2 / (2 * sigma ** 2))
    # print(feature_sim)
    # print("feature=",feature_sim)
    adj = pd_affinity * feature_sim    #将特征之间的相似性矩阵 feature_sim 与从 create_affinity_graph_from_scores 函数获得的邻接矩阵 pd_affinity 相乘，得到了静态邻接矩阵 adj
    # print("adj=",adj)
    # adj = (adj - adj.mean(axis=0)) / adj.std(axis=0)
    # adj = F.normalize(adj)
    # pd_affinity = (pd_affinity - pd_affinity.mean(axis=0)) / pd_affinity.std(axis=0)
    return pd_affinity   #返回量表之间的邻接矩阵