import torch

from torch.nn import Linear as Lin, Sequential as Seq
import torch.nn.functional as F
from torch import nn

class PAE(torch.nn.Module):  #计算边的权重
    # def __init__(self, input_dim, dropout=0.2):
    #     super(PAE, self).__init__()
    #     hidden=128
    #     self.parser =nn.Sequential(                                             #定义了一个神经网络模型，序列模型
    #             nn.Linear(input_dim, hidden, bias=True),
    #             nn.ReLU(inplace=True),
    #             nn.BatchNorm1d(hidden),
    #             nn.Dropout(dropout),
    #             nn.Linear(hidden, hidden, bias=True),
    #             )
    #     self.cos = nn.CosineSimilarity(dim=1, eps=1e-8)                         #初始化余弦相似度计算对象，计算两个张量之间的余弦相似度
    #     self.input_dim = input_dim
    #     self.model_init()
    #     self.relu = nn.ReLU(inplace=True)
    #     self.elu = nn.ReLU()
    #
    # def forward(self, x):
    #     x1 = x[:,0:self.input_dim]
    #     x2 = x[:,self.input_dim:]
    #     h1 = self.parser(x1)
    #     h2 = self.parser(x2)
    #     p = (self.cos(h1,h2) + 1)*0.5
    #     # p = abs(self.cos(h1, h2))
    #     # print(p)
    #     # print("p=",p)
    #     # print(p.shape)
    #     return p     #得到的余弦相似度   1表示完全相同，-1表示完全相反
    #
    # def model_init(self) -> object:
    #     for m in self.modules():
    #         if isinstance(m, Lin):  #isinstance() 函数来判断一个对象是否是一个已知的类型，类似 type()。
    #             torch.nn.init.kaiming_normal_(m.weight)
    #             m.weight.requires_grad = True
    #             if m.bias is not None:
    #                 m.bias.data.zero_()
    #                 m.bias.requires_grad = True
    #
    def __init__(self, input_dim, dropout=0.2, num_heads=4):
        super(PAE, self).__init__()
        hidden = 128

        # Multi-head Attention mechanism
        self.attention_heads = nn.ModuleList([
            nn.Sequential(
                nn.Linear(input_dim, hidden),
                nn.Tanh(),
                nn.Linear(hidden, input_dim)  # 输出与输入特征维度相同的注意力权重
            ) for _ in range(num_heads)
        ])

        self.parser = nn.Sequential(
            nn.Linear(input_dim, hidden, bias=True),
            nn.ReLU(inplace=True),
            nn.BatchNorm1d(hidden),
            nn.Dropout(dropout),
            nn.Linear(hidden, hidden, bias=True),
            nn.ReLU(inplace=True),
            nn.BatchNorm1d(hidden),
            nn.Dropout(dropout),
            nn.Linear(hidden, hidden, bias=True)
        )

        self.cos = nn.CosineSimilarity(dim=1, eps=1e-8)
        self.input_dim = input_dim
        self.model_init()
        self.relu = nn.ReLU(inplace=True)
        self.elu = nn.ELU()

    def forward(self, x):
        x1 = x[:, :self.input_dim]
        x2 = x[:, self.input_dim:]

        # Apply multi-head attention to select important features
        selected_x1 = self.apply_attention(x1)
        selected_x2 = self.apply_attention(x2)

        h1 = self.parser(selected_x1)
        h2 = self.parser(selected_x2)

        p = (self.cos(h1, h2) + 1) * 0.5
        return p

    def apply_attention(self, x):
        # Compute attention scores from multiple heads and average them
        attention_weights = [torch.softmax(head(x), dim=1) for head in self.attention_heads]
        attention_weights = torch.mean(torch.stack(attention_weights), dim=0)

        # Weighted sum to select important features
        selected_features = x * attention_weights
        return selected_features

    def model_init(self):
        for m in self.modules():
            if isinstance(m, nn.Linear):
                nn.init.kaiming_normal_(m.weight)
                m.weight.requires_grad = True
                if m.bias is not None:
                    m.bias.data.zero_()
                    m.bias.requires_grad = True
#用nn.model中的children方法获取直接子模块，用models获取所有子模块（包括直接子模块和间接子模块）
