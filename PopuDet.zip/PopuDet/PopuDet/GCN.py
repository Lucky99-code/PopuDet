import numpy as np
import torch
from torch.nn import Linear as Lin, Sequential as Seq
import torch_geometric as tg
import torch.nn.functional as F
from torch import nn
from PAE import PAE
from layers import general_GCN_layer, snowball_layer,truncated_krylov_layer


from pygcn.models import GCN

class graph_convolutional_network(nn.Module):
    def __init__(self, nfeat, nlayers, nhid, nclass, dropout):
        super(graph_convolutional_network, self).__init__()
        self.nfeat, self.nlayers, self.nhid, self.nclass = nfeat, nlayers, nhid, nclass
        self.dropout = dropout
        self.hidden = nn.ModuleList()

    def reset_parameters(self):
        for layer in self.hidden:
            layer.reset_parameters()
        self.out.reset_parameters()


class GCNLayer(nn.Module):
    def __init__(self, in_features, out_features):
        super(GCNLayer, self).__init__()
        self.in_features = in_features
        self.out_features = out_features
        self.weight = nn.Parameter(torch.Tensor(in_features, out_features))
        nn.init.xavier_uniform_(self.weight)  # 初始化权重

    def forward(self, feature, adj): #self.raw_features1, plv_aal_matrix   870×6670
        # 进行GCN运算
        support = torch.matmul(feature, self.weight)  #870×6670 6670×12
        #print('GCN,37,weight.shape:',self.weight.shape)  #6670×12
        output = torch.matmul(adj, support)  #871×871 870×12
        return output


class Gcn_Model(nn.Module):
    def __init__(self, input_dim, hidden_dim, output_dim):
        super(Gcn_Model, self).__init__()
        self.layer1 = GCNLayer(input_dim, hidden_dim)
        self.layer2 = GCNLayer(hidden_dim, output_dim)    # input_dim1 = 6670 input_dim2 = 19900 hidden_dim = 12 output_dim=3000

    def forward(self, feature, adj):     #self.raw_features1, plv_aal_matrix   870×6670
        # 第一层GCN
        h1 = F.relu(self.layer1(feature, adj))  #871×12
        # 第二层GCN
        output = self.layer2(h1, adj)   #871×12 871×871
        return output




class snowball(graph_convolutional_network):
    def __init__(self, nfeat, nlayers, nhid, nclass, dropout, activation):  #nfeat输入特征的维度，
        super(snowball, self).__init__(nfeat, nlayers, nhid, nclass, dropout)
        self.activation = activation
        for k in range(nlayers):                    #在每一个隐藏层创建一个雪球层
            self.hidden.append(snowball_layer(k * nhid + nfeat, nhid))  #每个雪球层的输入特征维度为k * nhid + nfeat, nhid
        self.out = snowball_layer(nlayers * nhid + nfeat, nclass)     #输出层的特征维度

    def forward(self, x, adj):
        list_output_blocks = []    #存储每一层的输出特征
        for layer, layer_num in zip(self.hidden, np.arange(self.nlayers)):
            if layer_num == 0:    #对第一层进行特殊处理
                list_output_blocks.append(
                    F.dropout(self.activation(layer(x, adj)), self.dropout, training=self.training))
            else:                  #其它层与之前层进行拼接
                list_output_blocks.append(
                    F.dropout(self.activation(layer(torch.cat([x] + list_output_blocks[0: layer_num], 1), adj)),
                              self.dropout, training=self.training))
        output = self.out(torch.cat([x] + list_output_blocks, 1), adj, eye=False)

        # output = (output - output.mean(axis=0)) / output.std(axis=0)
        F.normalize(output)
        return output


class truncated_krylov(graph_convolutional_network):
    def __init__(self, nfeat, nlayers, nhid, nclass, dropout, activation, n_blocks, adj, features):
        super(truncated_krylov, self).__init__(nfeat, nlayers, nhid, nclass, dropout)
        self.activation = activation
        LIST_A_EXP, LIST_A_EXP_X, A_EXP = [], [], torch.eye(adj.size()[0], dtype=adj.dtype).cuda()
        if str(adj.layout) == 'torch.sparse_coo':
            dense_adj = adj.to_dense()
        else:
            dense_adj = adj
        for _ in range(n_blocks):
            if nlayers > 1:
                indices = torch.nonzero(A_EXP).t()
                values = A_EXP[indices[0], indices[1]]
                LIST_A_EXP.append(torch.sparse.FloatTensor(indices, values, A_EXP.size()))

            LIST_A_EXP_X.append(torch.mm(A_EXP, features))
            torch.cuda.empty_cache()
            A_EXP = torch.mm(A_EXP, dense_adj)
        self.hidden.append(truncated_krylov_layer(nfeat, n_blocks, nhid, LIST_A_EXP_X_CAT=torch.cat(LIST_A_EXP_X, 1)))
        for _ in range(nlayers - 1):
            self.hidden.append(truncated_krylov_layer(nhid, n_blocks, nhid, LIST_A_EXP=LIST_A_EXP))
        self.out = truncated_krylov_layer(nhid, 1, nclass)

    def forward(self, x, adj):
        list_output_blocks = []
        for layer, layer_num in zip(self.hidden, np.arange(self.nlayers)):
            if layer_num == 0:
                list_output_blocks.append(
                    F.dropout(self.activation(layer(x, adj)), self.dropout, training=self.training))
            else:
                list_output_blocks.append(
                    F.dropout(self.activation(layer(list_output_blocks[layer_num - 1], adj)), self.dropout,
                              training=self.training))
        output = self.out(list_output_blocks[self.nlayers - 1], adj, eye=True)
        # output = (output - output.mean(axis=0)) / output.std(axis=0)
        output=F.normalize(output)
        return output



class EV_GCN(torch.nn.Module):
    def __init__(self, input_dim, num_classes, dropout, edgenet_input_dim, edge_dropout, hgc, lg):
        super(EV_GCN, self).__init__()
        K = 3
        hidden = [hgc for i in range(lg)]
        self.dropout = dropout
        self.edge_dropout = edge_dropout
        bias = False
        self.relu = torch.nn.ReLU(inplace=True)
        self.lg = lg
        self.gconv = nn.ModuleList()
        for i in range(lg):
            in_channels = input_dim if i == 0 else hidden[i - 1]
            self.gconv.append(tg.nn.ChebConv(in_channels, hidden[i], K, normalization='sym', bias=bias))
            # self.gconv.append(snowball(2000,8,16,2,0.2,nn.Tanh()))

        cls_input_dim = sum(hidden)   #隐藏层的输出总维度


        self.cls = nn.Sequential(
            torch.nn.Linear(cls_input_dim, 256),
            torch.nn.ReLU(inplace=True),
            nn.BatchNorm1d(256),
            torch.nn.Linear(256, num_classes))

        self.edge_net = PAE(input_dim=edgenet_input_dim // 2, dropout=dropout)  #处理边特征网络
        # a=PAE(input_dim=edgenet_input_dim // 2, dropout=dropout)
        # print("a===",a)
        self.model_init()

    def model_init(self):
        for m in self.modules():
            if isinstance(m, Lin):
                torch.nn.init.kaiming_normal_(m.weight)
                m.weight.requires_grad = True
                if m.bias is not None:
                    m.bias.data.zero_()
                    m.bias.requires_grad = True

    def forward(self, features, edge_index, edgenet_input, enforce_edropout=False):
        # if self.edge_dropout > 0:
        #     if enforce_edropout or self.training:
        #         one_mask = torch.ones([edgenet_input.shape[0], 1]).cuda()
        #         print(one_mask)
        #         self.drop_mask = F.dropout(one_mask, self.edge_dropout, True)
        #         self.bool_mask = torch.squeeze(self.drop_mask.type(torch.bool))
        #         edge_index = edge_index[:, self.bool_mask]
        #         print("edge_index",edge_index)
        #         print(edge_index.shape)
        #         edgenet_input = edgenet_input[self.bool_mask]

        edge_weight = torch.squeeze(self.edge_net(edgenet_input))   #用PAE来处理输入的边特征
        # print("edge_weight11111", edge_weight)
        # print(edge_weight.shape)
        features = F.dropout(features, self.dropout, self.training)
        # print(features.shape)

        h = self.relu(self.gconv[0](features, edge_index, edge_weight))
        h0 = h

        for i in range(1, self.lg):
            h = F.dropout(h, self.dropout, self.training)
            h = self.relu(self.gconv[i](h, edge_index, edge_weight))
            jk = torch.cat((h0, h), axis=1)
            h0 = jk
        logit = self.cls(jk)

        return logit, edge_weight

