import numpy as np
import data.ABIDEParser2 as Reader
# 加载1D文件中的数据
import torch
import os
import glob
import matplotlib.pyplot as plt
import scipy.signal as signal
import pandas as pd
def find_files_with_suffix(directory,  suffix):
    # 构造文件名模式
    pattern = os.path.join(directory,'*' + suffix)

    # 使用glob模块搜索文件
    matching_files = glob.glob(pattern)
    print(matching_files)
    return matching_files

# 要搜索的文件夹路径
directory_path = 'C:/study experiment/MAMF-GCN-main/data/ABIDE_pcp/cpac/filt_noglobal/'

source_file=open('C:/study experiment/MAMF-GCN-main/data/ABIDE_pcp/cpac/filt_noglobal/subject_IDs.txt',"r",encoding="utf-8")


#aal文件列表
result_aal=[]
#cc200文件列表
result_cc200=[]

#获取需要的文件夹序号（已经运行完成）
needed_index_list=source_file.read().splitlines()
for i in needed_index_list:
    # 获取需要的文件名
    # 直接选取['50003_aal_correlation.mat', '50003_cc200_correlation.mat', 'Pitt_0050003_rois_aal.1D', 'Pitt_0050003_rois_cc200.1D']
    needed_aal_file_name = os.listdir(directory_path+i)[2]     #文件夹的名称
    needed_cc20_file_name= os.listdir(directory_path+i)[3]
    #拼接收集
    result_aal.append(directory_path+i+"/"+needed_aal_file_name)#获得所有aal文件路径
    result_cc200.append(directory_path+i+"/"+needed_cc20_file_name)#获得所有cc200文件路径


print("result_aal:",result_aal)
print("result_cc200:",result_cc200)

# m=len(result_aal)
# matrix = np.zeros((m, m))  #PLV矩阵
m=len(result_cc200)
#print(m)

index_i=0
index_j=0
# #计算aal的plv值(已经运行完成)
# with open("plv_values.txt", "w") as file:
#     for i in result_aal:
#         index_i=index_i+1
#         data1 = np.loadtxt(i)
#
#         length = data1.shape[0]
#         for j in result_aal[index_i:]:
#             index_j=index_i+1
#             data2=np.loadtxt(j)
#
#             if length > data2.shape[0]:
#                 length=data2.shape[0]
#             # print("data1" + str(data2.shape[0]))
#             plv = Reader.calculate_PLV_between_subjects(data1[0:length], data2[0:length])
#             if plv>0:
#                 print(plv)
#                 file.write(str(plv) + "\n")
#             else:
#                 print('0')
#                 file.write('0'+"\n")

# #计算cc200的plv值(已经运行完成)   待会儿运行就不要print了
# with open("plv_values_cc200.txt", "w") as file:
#     for i in result_cc200:
#         index_i=index_i+1
#         data1 = np.loadtxt(i)
#
#         length = data1.shape[0]
#         for j in result_cc200[index_i:]:
#             index_j=index_i+1
#             data2=np.loadtxt(j)
#
#             if length > data2.shape[0]:
#                 length=data2.shape[0]
#             # print("data1" + str(data2.shape[0]))
#             plv = Reader.calculate_PLV_between_subjects(data1[0:length], data2[0:length])
#             if plv > 0:
#                 print(plv)
#                 file.write(str(plv) + "\n")
#             else:
#                 #print('0')
#                 file.write('0' + "\n")

#将plv值列表转化为矩阵——aal的plv矩阵

#读取文本中的数据
with open("plv_values.txt", "r") as f:
    lines = f.readlines()

# 将文本中的数据转换为整数列表
data = [float(x.strip()) for x in lines]


# 获取数据的长度
n = len(data)
m=0
#（已经运行完成）
aal_matrix = []
with open("plv_aal_matrix.txt", "w") as f:
    for i in range(871):
        print("dayin:i",i)
        row=[]
        for j in range(871):
            if(i==j):
                row.append(1)
            elif(i<j):
                row.append(data[m])
                m=m+1
            elif(i>j):
                row.append(aal_matrix[j][i])
        # 将一行写入文本文件
        f.write(" ".join(map(str, row)) + "\n")
        aal_matrix.append(row)


#将plv值列表转化为矩阵——cc200的plv矩阵

#读取文本中的数据
with open("plv_values_cc200.txt", "r") as f:
    lines = f.readlines()

# 将文本中的数据转换为整数列表
data = [float(x.strip()) for x in lines]


# 获取数据的长度
n = len(data)
m=0
#（已经运行完成）
cc200_matrix = []
with open("plv_cc200_matrix.txt", "w") as f:
    for i in range(871):
        row=[]
        for j in range(871):
            if(i==j):
                row.append(1)
            elif(i<j):
                row.append(data[m])
                m=m+1
            elif(i>j):
                row.append(cc200_matrix[j][i])
        # 将一行写入文本文件
        f.write(" ".join(map(str, row)) + "\n")
        cc200_matrix.append(row)

#先放在一维向量里 然后再放进矩阵的话就不用每次都算 耽误时间 计算对称矩阵
# for k in m:
#     for l in m:
#         if(k==l):
#             matrix[k,l]=1
#         elif(k<l):
#             matrix[k,l]=plv_list[index]
#             index=index+1
#         elif(k>l):
#             matrix[k,l]=matrix[l,k]
#
# print(matrix)

#
# # 从文本文件中读取对称矩阵数据到 numpy 数组
# symmetric_matrix_np = np.loadtxt('plv_cc200_matrix.txt')
#
# # 将 numpy 数组转换为 PyTorch 的 Tensor 类型
# symmetric_matrix_tensor = torch.tensor(symmetric_matrix_np)
#
# # 检查 symmetric_matrix_tensor 是否为 PyTorch 的 Tensor 类型
# if isinstance(symmetric_matrix_tensor, torch.Tensor):
#     print("symmetric_matrix_tensor 是 PyTorch 的 Tensor 类型")
# else:
#     print("symmetric_matrix_tensor 不是 PyTorch 的 Tensor 类型")