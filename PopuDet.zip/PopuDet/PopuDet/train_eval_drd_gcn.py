import sklearn.preprocessing
import torch
from sklearn.metrics import roc_auc_score,roc_curve,auc
import matplotlib.pyplot as plt
from torch import nn, softmax
from sklearn.metrics import roc_auc_score,roc_curve
from models import DRDGCN
from models import Attention_fea
import torch.nn.functional as F
from PAE import PAE
from opt import *
from utils.metrics import accuracy,auc,prf
from scipy.special import softmax
#from utils.LoggerFactory import get_logger
# logger=get_logger()
# logger.info('ggggggg{}'.format())
#from data.dataprocess import dataloader
from data.dataprocess import *
import pandas as pdy
import numpy as np
from dataloader_GCN import *
import data.ABIDEParser2 as ABIDEParser
os.environ["CUDA_VISIBLE_DEVICES"] = '0'

from pygcn.models import GCN
#args=parser.parse_args()
#logger.info('The list of medel initialization parameters is {}'.format(args.__dict__))
if __name__ == '__main__':
    opt = OptInit().initialize()

    print('  Loading dataset ...')
    dl = dataloader()  #实例化

    raw_features1,raw_features2, y, nonimg = dl.load_data()    #加载未处理的数据


    print("Data type of raw_features1:", raw_features1.dtype)
    print("Data type of raw_features2:", raw_features2.dtype)


    n_folds = 10
    print("Data type of raw_features1:", raw_features1.dtype)
    print("Data type of raw_features2:", raw_features2.dtype)

    cv_splits = dl.data_split(n_folds)  #进行一个模板的k折划分
    # print(cv_splits)
    global mean_tpr
    global mean_fpr
    mean_tpr = 0.0
    mean_fpr = np.linspace(0, 1, 100)
    global cnt
    cnt = 0
    corrects = np.zeros(n_folds, dtype=np.int32)   #用于存储每一折交叉验证中的正确预测数量。
    accs = np.zeros(n_folds, dtype=np.float32)      #用于存储每一折交叉验证的准确率。
    aucs = np.zeros(n_folds, dtype=np.float32)      #用于存储每一折交叉验证的AUC值
    prfs = np.zeros([n_folds, 3], dtype=np.float32)  #用于存储每一折交叉验证的精确度、召回率和F1分数

    #process features and plv_matrix


    for fold in range(n_folds):
        print("\r\n========================== Fold {} ==========================".format(fold))
        train_ind = cv_splits[fold][0]
        test_ind = cv_splits[fold][1]

        if torch.cuda.is_available():
            torch.cuda.manual_seed(n_folds)

        np.random.seed(n_folds)  # Numpy module.
        random.seed(n_folds)

        print('  Constructing graph data...')


        # extract node features    #GCN这儿的卷积权重
        node_ftr1,node_ftr2 = dl.get_node_features(train_ind)   #已经进行了RFE了  形状（num_subjects×num_features）两个模板处理完的特征矩阵  2000特征
        #node_feature = torch.cat((node_ftr1,node_ftr2),dim=1)
        #get_node_feature-->feature_selection  preprocess_features
        #node_ftr1(aal)    atlas1    node_ftr2(cc200)   atlas2


        for topk in range(2, 16):
            construct_graph(node_ftr1, topk)   #为什么是从2到15进行迭代呢？？？？？
            #f1 = open('C:/study experiment/DRD-GCN-main/data/MDD/knn/tmp.txt', 'r')
            #f2 = open('C:/study experiment/DRD-GCN-main/data/MDD/knn/c' + str(topk) + '.txt', 'w')
            f1 = open('D:/xuting/study experiment/my experiment/DRD-GCN-main/DRD-GCN-main/data/ABIDE/knn_aal/tmp.txt', 'r')
            f2 = open('D:/xuting/study experiment/my experiment/DRD-GCN-main/DRD-GCN-main/data/ABIDE/knn_aal/c' + str(topk) + '.txt', 'w')

            lines = f1.readlines()
            for line in lines:
                start, end = line.strip('\n').split(' ')
                if int(start) < int(end):         #在构图时每条边只存储依一次，小的为起始节点，大的为终止节点
                    f2.write('{} {}\n'.format(start, end))
            f2.close()
        for topk in range(2, 16):

            construct_graph2(node_ftr2, topk)
            #f1 = open('/media/pjc/expriment/mdd_exam/pjc/EV_GCN-MDD/data/MDD/knn_ho2/tmp.txt', 'r')改
            f1 = open('D:/xuting/study experiment/my experiment/DRD-GCN-main/DRD-GCN-main/data/ABIDE/knn_cc200/tmp.txt', 'r')
            f2 = open('D:/xuting/study experiment/my experiment/DRD-GCN-main/DRD-GCN-main/data/ABIDE/knn_cc200/c' + str(topk) + '.txt', 'w')

            lines = f1.readlines()
            for line in lines:
                start, end = line.strip('\n').split(' ')
                if int(start) < int(end):
                    f2.write('{} {}\n'.format(start, end))
            f2.close()



        # # get PAE inputs
        # edge_index, edgenet_input = dl.get_PAE_inputs(nonimg)  #得到的就是所有受试者中相似性大于1.1的边索引和边特征（两个受试者特征的拼接）
        #
        # # normalization for PAE
        # edgenet_input = (edgenet_input - edgenet_input.mean(axis=0)) / edgenet_input.std(axis=0)
        # edge_net = PAE(2 * nonimg.shape[1] // 2, 0.2)   #使用PAE处理输入特征，得到每条边的权重
        # edgenet_input = torch.from_numpy(edgenet_input)
        # edge_weight = torch.squeeze(edge_net(edgenet_input))  #两个节点的相似分数，边权重

        #fadj,fadj2 = load_graph(config=opt.n)    #加载AAL和CC200图的邻接矩阵
        #print("AAL的邻接矩阵：",fadj)

        # 非图像数据（例如nonimg）的特征数量为num_features
        num_features = nonimg.shape[1]
        num_selected_features = 4  # 选择4个重要特征
        # get PAE inputs
        edge_index, edgenet_input = dl.get_PAE_inputs(nonimg)  # 得到的就是所有受试者中相似性大于1.1的边索引和边特征（两个受试者特征的拼接）

        # normalization for PAE
        edgenet_input = (edgenet_input - edgenet_input.mean(axis=0)) / edgenet_input.std(axis=0)
        edge_net = PAE(input_dim=num_features,  dropout=0.2)
        edgenet_input = torch.from_numpy(edgenet_input)
        edge_weight = torch.squeeze(edge_net(edgenet_input))  # 两个节点的相似分数，边权重

        aij = np.zeros([raw_features1.shape[0], raw_features1.shape[0]])  #构建节点间的边权重矩阵
        for i in range(raw_features1.shape[0]):
            n = edge_index.shape[1]
            for k in range(n):
                if i == edge_index[0][k]:
                    aij[i][edge_index[1][k]] = edge_weight[k]

        sadj =aij   #得到PAE算出来的邻接矩阵

            # 从文本文件中读取对称矩阵数据到 numpy 数组
        plv_aal_matrix_np = np.loadtxt('plv_aal_matrix.txt')
        plv_cc200_matrix_np = np.loadtxt('plv_cc200_matrix.txt')

        print("plv_aal_matrix:",plv_aal_matrix_np)
        print("plv_cc200_matrix:", plv_cc200_matrix_np)
            # 将 numpy 数组转换为 PyTorch 的 Tensor 类型
        # plv_aal_matrix = torch.tensor(plv_aal_matrix_np, dtype=torch.float32)
        # plv_cc200_matrix = torch.tensor(plv_cc200_matrix_np, dtype=torch.float32)
        fadj = plv_aal_matrix_np
        fadj2 = plv_cc200_matrix_np

        print("fadj######:",fadj)
        model = DRDGCN(nfeat=2000,

                      nhid=32,
                      out=16,
                      nclass=2,
                      nhidlayer=1,
                      dropout=0.4,
                      # lamda=1.2,#在0.5-1.5进行调节
                      # alpha=0.3,#0.1-0.9
                      # variant=False,
                      baseblock="inceptiongcn",
                      inputlayer="gcn",
                      outputlayer="gcn",
                      nbaselayer=6,
                      activation=F.relu,
                      withbn=False,
                      withloop=False,
                      aggrmethod="concat",
                      mixmode=False,
                     )
        model = model.to(opt.device)




        # build loss, optimizer, metric
        loss_fn = torch.nn.CrossEntropyLoss()
        optimizer = torch.optim.Adam(model.parameters(), lr=opt.lr, weight_decay=opt.wd)

        features_cuda = torch.as_tensor(node_ftr1, dtype=torch.float32).to(opt.device)
        features_cuda2 = torch.as_tensor(node_ftr2, dtype=torch.float32).to(opt.device)
        edge_index = torch.as_tensor(edge_index, dtype=torch.long).to(opt.device)
        edgenet_input = torch.as_tensor(edgenet_input, dtype=torch.float32).to(opt.device)
        aij = torch.as_tensor(aij, dtype=torch.float32).to(opt.device)
        sadj = torch.as_tensor(sadj, dtype=torch.float32).to(opt.device)
        fadj = torch.as_tensor(fadj, dtype=torch.float32).to(opt.device) #AAL
        fadj2 = torch.as_tensor(fadj2, dtype=torch.float32).to(opt.device) #CC200
        labels = torch.as_tensor(y, dtype=torch.long).to(opt.device)
        fold_model_path = opt.ckpt_path + "/fold{}.pth".format(fold)
        # print("features_cude:",features_cuda)
        # print("features_cude2:", features_cuda2)
        # 融合两个特征
        # 创建Attention_fea实例
        attention = Attention_fea(in_size=2000, hidden_size=2).to(features_cuda.device)
        # 将attention移动到指定的设备
       # attention = attention.to(opt.device)
        fused_features, attention_weights1,attention_weights2 = attention(features_cuda, features_cuda2)
        # print("train_eval_mamf_gcn:fused_features:",fused_features,'\n')
        # print("train_eval_mamf_gcn:attention_weights:",attention_weights1,attention_weights2)
        # print("features:",features)

        def plot_embedding(data, label, title):
            plt.figure()
            x_min, x_max = np.min(data, 0), np.max(data, 0)
            data = (data - x_min) / (x_max - x_min)
            p = [[0] for _ in range(10)]
            p2 = [[0] for _ in range(10)]
            for i in range(len(label)):
                if label[i] == 0:
                    p = plt.scatter(data[i, 0], data[i, 1], lw=0.1, c='#FFD700')#, alpha=0.8
                elif label[i] == 1:
                    p2 = plt.scatter(data[i, 0], data[i, 1], lw=0.1, c='#800080')
            plt.legend((p, p2), ('HC', 'ASD'))
            plt.savefig('./draw_figure/ASD/Result{:d}.png'.format(fold), dpi=600)

        def train():
            print("  Number of training samples %d" % len(train_ind))
            print("  Start training...\r\n")
            acc = 0
            for epoch in range(opt.num_iter):
                model.train()
                optimizer.zero_grad()
                with torch.set_grad_enabled(True):
                    node_logits, att, emb1, com1, com2, com3, emb2, emb3 = model(fused_features, sadj, fadj, fadj2)
                    #node_logits, att, emb1, com1, com2,com3, emb2,emb3 = model(features_cuda, sadj, fadj,fadj2)
                    loss_class = loss_fn(node_logits[train_ind], labels[train_ind])
                    loss_dep = (loss_dependence(emb1, com1, raw_features1.shape[0])
                                + loss_dependence(emb2, com2, raw_features1.shape[0])
                                +loss_dependence(emb3, com3, raw_features1.shape[0])) / 3
                    # loss_dep = (loss_dependence(emb1, com1, features.shape[0])   #修改过的
                    #             + loss_dependence(emb2, com2, features.shape[0])
                    #             + loss_dependence(emb3, com3, features.shape[0])) / 3

                    loss_com = common_loss(com1, com2,com3)
                    loss = loss_class + 1e-12 * loss_dep + 0.00005 * loss_com
                    loss.backward(retain_graph=True)   #loss.backward()
                    optimizer.step()

                correct_train, acc_train = accuracy(node_logits[train_ind].detach().cpu().numpy(), y[train_ind])

                model.eval()
                with torch.set_grad_enabled(False):

                    #node_logits, att,emb1, com1, com2,com3, emb2,emb3 = model(features_cuda, sadj, fadj,fadj2)
                    node_logits, att, emb1, com1, com2, com3, emb2, emb3 = model(fused_features, sadj, fadj, fadj2)

                logits_test = node_logits[test_ind].detach().cpu().numpy()
                correct_test, acc_test = accuracy(logits_test, y[test_ind])
                # pos_probs = softmax(logits_test, axis=1)[:, 1]
                # pos_probs = logits_test[:, 1]
                # fpr,tpr,thresholds =roc_curve(pos_probs, y[test_ind])
                # auc_plot =roc_auc_score(pos_probs, y[test_ind])
                auc_test = auc(logits_test, y[test_ind])
                prf_test = prf(logits_test, y[test_ind])

                # plt.plot(fpr,tpr)
                # plt.title("auc=%.4f"%(auc_plot))
                # plt.xlabel("False Positive Rate")
                # plt.ylabel("True Positive Rate")
                # plt.fill_between(fpr,tpr,where=(tpr>0),color='green',alpha=0.5)
                # plt.show()
                print("Epoch: {}, Train accuracy: {:.5f}, Test accuracy: {:.5f}".format(epoch, acc_train, acc_test))
                # print("Epoch: {},\tce loss: {:.5f},\ttrain acc: {:.5f}".format(epoch, loss.item(), acc_train.item()))
                if acc_test > acc and epoch > 9:
                    acc = acc_test
                    correct = correct_test
                    aucs[fold] = auc_test
                    prfs[fold] = prf_test
                    if opt.ckpt_path != '':
                        if not os.path.exists(opt.ckpt_path):
                            # print("Checkpoint Directory does not exist! Making directory {}".format(opt.ckpt_path))
                            os.makedirs(opt.ckpt_path)
                        torch.save(model.state_dict(), fold_model_path)

            accs[fold] = acc
            corrects[fold] = correct
            print("\r\n => Fold {} test accuacry {:.5f}".format(fold, acc))



        def evaluate():
            print("  Number of testing samples %d" % len(test_ind))
            print('  Start testing...')
            global cnt
            global mean_tpr
            model.load_state_dict(torch.load(fold_model_path))
            model.eval()
            # node_logits = model(features_cuda, edge_index, edgenet_input)
            node_logits, att, emb1, com1, com2,com3, emb2, emb,emb3 = model(fused_features, sadj, fadj,fadj2)
            #node_logits, att, emb1, com1, com2,com3, emb2, emb,emb3 = model(features_cuda, sadj, fadj,fadj2)
            logits_test = node_logits[test_ind].detach().cpu().numpy()
            corrects[fold], accs[fold] = accuracy(logits_test, y[test_ind])
            aucs[fold] = auc(logits_test, y[test_ind])
            prfs[fold] = prf(logits_test, y[test_ind])
            cnt += 1
            pos_probs = softmax(logits_test, axis=1)[:, 1]
            fpr, tpr, thresholds = roc_curve(y[test_ind], pos_probs)
            mean_tpr += np.interp(mean_fpr, fpr, tpr)
            mean_tpr[0] = 0.0
            roc_auc = sklearn.metrics.auc(fpr, tpr)
            lw = 2
            plt.plot(fpr, tpr, lw=lw, label='ROC fold {0:d} curve (area= {1:.2f})'.format(cnt, roc_auc))

            print("  Fold {} test accuracy {:.5f}, AUC {:.5f}".format(fold, accs[fold], aucs[fold]))




        if opt.train == 1:
            train()
        elif opt.train == 0:
            evaluate()

    print("\r\n========================== Finish ==========================")
    #n_samples = raw_features1.shape[0]
    n_samples = fused_features.shape[0]
    acc_nfold = np.sum(corrects) / n_samples
    print("=> Average test accuracy in {}-fold CV: {:.5f}".format(n_folds, acc_nfold))
    print("=> Average test AUC in {}-fold CV: {:.5f}".format(n_folds, np.mean(aucs)))
    se, sp, f1 = np.mean(prfs, axis=0)
    print("=> Average test sensitivity {:.5f}, specificity {:.5f}, F1-score {:.5f}".format(se, sp, f1))


    #
    # for fold in range(n_folds):
    #     print("\r\n========================== Fold {} ==========================".format(fold))
    #     train_ind = cv_splits[fold][0]
    #     test_ind = cv_splits[fold][1]
    #
    #     if torch.cuda.is_available():
    #         torch.cuda.manual_seed(n_folds)
    #
    #     np.random.seed(n_folds)  # Numpy module.
    #     random.seed(n_folds)
    #
    #     print('  Constructing graph data...')
    #
    #
    #     # extract node features    #GCN这儿的卷积权重
    #     node_ftr1,node_ftr2 = dl.get_node_features(train_ind)   #已经进行了RFE了  形状（num_subjects×num_features）两个模板处理完的特征矩阵  2000特征
    #     #node_feature = torch.cat((node_ftr1,node_ftr2),dim=1)
    #     #get_node_feature-->feature_selection  preprocess_features
    #     #node_ftr1(aal)    atlas1    node_ftr2(cc200)   atlas2
    #
    #
    #     for topk in range(2, 16):
    #         construct_graph(node_ftr1, topk)   #为什么是从2到15进行迭代呢？？？？？
    #         #f1 = open('C:/study experiment/MAMF-GCN-main/data/MDD/knn/tmp.txt', 'r')
    #         #f2 = open('C:/study experiment/MAMF-GCN-main/data/MDD/knn/c' + str(topk) + '.txt', 'w')
    #         f1 = open('C:/study experiment/MAMF-GCN-main/data/ABIDE/knn_aal/tmp.txt', 'r')
    #         f2 = open('C:/study experiment/MAMF-GCN-main/data/ABIDE/knn_aal/c' + str(topk) + '.txt', 'w')
    #
    #         lines = f1.readlines()
    #         for line in lines:
    #             start, end = line.strip('\n').split(' ')
    #             if int(start) < int(end):         #在构图时每条边只存储依一次，小的为起始节点，大的为终止节点
    #                 f2.write('{} {}\n'.format(start, end))
    #         f2.close()
    #     for topk in range(2, 16):
    #
    #         construct_graph2(node_ftr2, topk)
    #         #f1 = open('/media/pjc/expriment/mdd_exam/pjc/EV_GCN-MDD/data/MDD/knn_ho2/tmp.txt', 'r')改
    #         f1 = open('C:/study experiment/MAMF-GCN-main/data/ABIDE/knn_cc200/tmp.txt', 'r')
    #         f2 = open('C:/study experiment/MAMF-GCN-main/data/ABIDE/knn_cc200/c' + str(topk) + '.txt', 'w')
    #
    #         lines = f1.readlines()
    #         for line in lines:
    #             start, end = line.strip('\n').split(' ')
    #             if int(start) < int(end):
    #                 f2.write('{} {}\n'.format(start, end))
    #         f2.close()
    #
    #
    #
    #     # get PAE inputs
    #     edge_index, edgenet_input = dl.get_PAE_inputs(nonimg)  #得到的就是所有受试者中相似性大于1.1的边索引和边特征（两个受试者特征的拼接）
    #
    #     # normalization for PAE
    #     edgenet_input = (edgenet_input - edgenet_input.mean(axis=0)) / edgenet_input.std(axis=0)
    #     edge_net = PAE(2 * nonimg.shape[1] // 2, 0.2)   #使用PAE处理输入特征，得到每条边的权重
    #     edgenet_input = torch.from_numpy(edgenet_input)
    #     edge_weight = torch.squeeze(edge_net(edgenet_input))  #两个节点的相似分数，边权重
    #
    #
    #     aij = np.zeros([raw_features1.shape[0], raw_features1.shape[0]])  #构建节点间的边权重矩阵
    #     for i in range(raw_features1.shape[0]):
    #         n = edge_index.shape[1]
    #         for k in range(n):
    #             if i == edge_index[0][k]:
    #                 aij[i][edge_index[1][k]] = edge_weight[k]
    #
    #     sadj =aij   #得到PAE算出来的邻接矩阵
    #
    #     model = MAMFGCN(nfeat=2000,
    #                   nhid=32,
    #                   out=16,
    #                   nclass=2,
    #                   nhidlayer=1,
    #                   dropout=0.4,
    #                   baseblock="inceptiongcn",
    #                   inputlayer="gcn",
    #                   outputlayer="gcn",
    #                   nbaselayer=6,
    #                   activation=F.relu,
    #                   withbn=False,
    #                   withloop=False,
    #                   aggrmethod="concat",
    #                   mixmode=False,
    #                  )
    #     model = model.to(opt.device)
    #
    #
    #
    #
    #     # build loss, optimizer, metric
    #     loss_fn = torch.nn.CrossEntropyLoss()
    #     optimizer = torch.optim.Adam(model.parameters(), lr=opt.lr, weight_decay=opt.wd)
    #
    #     features_cuda = torch.as_tensor(node_ftr1, dtype=torch.float32).to(opt.device)
    #     features_cuda2 = torch.as_tensor(node_ftr2, dtype=torch.float32).to(opt.device)
    #     edge_index = torch.as_tensor(edge_index, dtype=torch.long).to(opt.device)
    #     edgenet_input = torch.as_tensor(edgenet_input, dtype=torch.float32).to(opt.device)
    #     aij = torch.as_tensor(aij, dtype=torch.float32).to(opt.device)
    #     sadj = torch.as_tensor(sadj, dtype=torch.float32).to(opt.device)
    #     fadj = torch.as_tensor(fadj, dtype=torch.float32).to(opt.device) #AAL
    #     fadj2 = torch.as_tensor(fadj2, dtype=torch.float32).to(opt.device) #CC200
    #     labels = torch.as_tensor(y, dtype=torch.long).to(opt.device)
    #     fold_model_path = opt.ckpt_path + "/fold{}.pth".format(fold)
    #     # print("features_cude:",features_cuda)
    #     # print("features_cude2:", features_cuda2)
    #
    #     def plot_embedding(data, label, title):
    #         plt.figure()
    #         x_min, x_max = np.min(data, 0), np.max(data, 0)
    #         data = (data - x_min) / (x_max - x_min)
    #         p = [[0] for _ in range(10)]
    #         p2 = [[0] for _ in range(10)]
    #         for i in range(len(label)):
    #             if label[i] == 0:
    #                 p = plt.scatter(data[i, 0], data[i, 1], lw=0.1, c='#FFD700')#, alpha=0.8
    #             elif label[i] == 1:
    #                 p2 = plt.scatter(data[i, 0], data[i, 1], lw=0.1, c='#800080')
    #         plt.legend((p, p2), ('HC', 'ASD'))
    #         plt.savefig('./draw_figure/ASD/Result{:d}.png'.format(fold), dpi=600)
    #
    #     def train():
    #         print("  Number of training samples %d" % len(train_ind))
    #         print("  Start training...\r\n")
    #         acc = 0
    #         for epoch in range(opt.num_iter):
    #             model.train()
    #             optimizer.zero_grad()
    #             with torch.set_grad_enabled(True):
    #                 node_logits, att, emb1, com1, com2, com3, emb2, emb3 = model(features_cuda, sadj, fadj, fadj2)
    #                 #node_logits, att, emb1, com1, com2,com3, emb2,emb3 = model(features_cuda, sadj, fadj,fadj2)
    #                 loss_class = loss_fn(node_logits[train_ind], labels[train_ind])
    #                 loss_dep = (loss_dependence(emb1, com1, raw_features1.shape[0])
    #                             + loss_dependence(emb2, com2, raw_features1.shape[0])
    #                             +loss_dependence(emb3, com3, raw_features1.shape[0])) / 3
    #                 # loss_dep = (loss_dependence(emb1, com1, features.shape[0])   #修改过的
    #                 #             + loss_dependence(emb2, com2, features.shape[0])
    #                 #             + loss_dependence(emb3, com3, features.shape[0])) / 3
    #
    #                 loss_com = common_loss(com1, com2,com3)
    #                 loss = loss_class + 1e-12 * loss_dep + 0.00005 * loss_com
    #                 loss.backward()
    #                 optimizer.step()
    #             correct_train, acc_train = accuracy(node_logits[train_ind].detach().cpu().numpy(), y[train_ind])
    #
    #             model.eval()
    #             with torch.set_grad_enabled(False):
    #
    #                 #node_logits, att,emb1, com1, com2,com3, emb2,emb3 = model(features_cuda, sadj, fadj,fadj2)
    #                 node_logits, att, emb1, com1, com2, com3, emb2, emb3 = model(features_cuda, sadj, fadj, fadj2)
    #
    #             logits_test = node_logits[test_ind].detach().cpu().numpy()
    #             correct_test, acc_test = accuracy(logits_test, y[test_ind])
    #             # pos_probs = softmax(logits_test, axis=1)[:, 1]
    #             # pos_probs = logits_test[:, 1]
    #             # fpr,tpr,thresholds =roc_curve(pos_probs, y[test_ind])
    #             # auc_plot =roc_auc_score(pos_probs, y[test_ind])
    #             auc_test = auc(logits_test, y[test_ind])
    #             prf_test = prf(logits_test, y[test_ind])
    #
    #             # plt.plot(fpr,tpr)
    #             # plt.title("auc=%.4f"%(auc_plot))
    #             # plt.xlabel("False Positive Rate")
    #             # plt.ylabel("True Positive Rate")
    #             # plt.fill_between(fpr,tpr,where=(tpr>0),color='green',alpha=0.5)
    #             # plt.show()
    #
    #             # print("Epoch: {},\tce loss: {:.5f},\ttrain acc: {:.5f}".format(epoch, loss.item(), acc_train.item()))
    #             if acc_test > acc and epoch > 9:
    #                 acc = acc_test
    #                 correct = correct_test
    #                 aucs[fold] = auc_test
    #                 prfs[fold] = prf_test
    #                 if opt.ckpt_path != '':
    #                     if not os.path.exists(opt.ckpt_path):
    #                         # print("Checkpoint Directory does not exist! Making directory {}".format(opt.ckpt_path))
    #                         os.makedirs(opt.ckpt_path)
    #                     torch.save(model.state_dict(), fold_model_path)
    #
    #         accs[fold] = acc
    #         corrects[fold] = correct
    #         print("\r\n => Fold {} test accuacry {:.5f}".format(fold, acc))
    #
    #
    #
    #     def evaluate():
    #         print("  Number of testing samples %d" % len(test_ind))
    #         print('  Start testing...')
    #         global cnt
    #         global mean_tpr
    #         model.load_state_dict(torch.load(fold_model_path))
    #         model.eval()
    #         # node_logits = model(features_cuda, edge_index, edgenet_input)
    #         node_logits, att, emb1, com1, com2,com3, emb2, emb,emb3 = model(features_cuda, sadj, fadj,fadj2)
    #         #node_logits, att, emb1, com1, com2,com3, emb2, emb,emb3 = model(features_cuda, sadj, fadj,fadj2)
    #         logits_test = node_logits[test_ind].detach().cpu().numpy()
    #         corrects[fold], accs[fold] = accuracy(logits_test, y[test_ind])
    #         aucs[fold] = auc(logits_test, y[test_ind])
    #         prfs[fold] = prf(logits_test, y[test_ind])
    #         cnt += 1
    #         pos_probs = softmax(logits_test, axis=1)[:, 1]
    #         fpr, tpr, thresholds = roc_curve(y[test_ind], pos_probs)
    #         mean_tpr += np.interp(mean_fpr, fpr, tpr)
    #         mean_tpr[0] = 0.0
    #         roc_auc = sklearn.metrics.auc(fpr, tpr)
    #         lw = 2
    #         plt.plot(fpr, tpr, lw=lw, label='ROC fold {0:d} curve (area= {1:.2f})'.format(cnt, roc_auc))
    #
    #         print("  Fold {} test accuracy {:.5f}, AUC {:.5f}".format(fold, accs[fold], aucs[fold]))
    #
    #
    #
    #
    #     if opt.train == 1:
    #         train()
    #     elif opt.train == 0:
    #         evaluate()
    #
    # print("\r\n========================== Finish ==========================")
    # #n_samples = raw_features1.shape[0]
    # n_samples = features_cuda.shape[0]
    # acc_nfold = np.sum(corrects) / n_samples
    # print("=> Average test accuracy in {}-fold CV: {:.5f}".format(n_folds, acc_nfold))
    # print("=> Average test AUC in {}-fold CV: {:.5f}".format(n_folds, np.mean(aucs)))
    # se, sp, f1 = np.mean(prfs, axis=0)
    # print("=> Average test sensitivity {:.5f}, specificity {:.5f}, F1-score {:.5f}".format(se, sp, f1))
