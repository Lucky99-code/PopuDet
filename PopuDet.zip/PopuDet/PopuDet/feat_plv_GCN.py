

# 定义优化器和损失函数
optimizer = torch.optim.Adam(gcn_model.parameters(), lr=0.001)
criterion = torch.nn.MSELoss()  # 均方误差损失